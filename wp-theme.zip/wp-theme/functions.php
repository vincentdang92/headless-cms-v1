<?php
/**
 * Headless CMS — functions.php
 *
 * Điền 3 hằng số này trước khi dùng:
 *   NEXTJS_URL      URL của Next.js frontend, dùng cho webhook + redirect
 *   REVALIDATION_SECRET   Phải khớp với .env.local của Next.js
 *   WP_API_SECRET   Phải khớp với .env.local của Next.js
 */

define( 'NEXTJS_URL',            'http://localhost:3000' );
define( 'REVALIDATION_SECRET',   'REPLACE_WITH_SECRET' );
define( 'WP_API_SECRET',         'REPLACE_WITH_SECRET' );

// ── 1. ACF Options Page ───────────────────────────────────────────────────────

add_action( 'acf/init', function () {
    if ( ! function_exists( 'acf_add_options_page' ) ) return;

    acf_add_options_page( [
        'page_title' => 'Cài Đặt Giao Diện',
        'menu_title' => 'Site Settings',
        'menu_slug'  => 'site-settings',
        'capability' => 'manage_options',
        'icon_url'   => 'dashicons-admin-customizer',
        'position'   => 2,
    ] );
} );

// ── 2. REST API — xác thực bằng header bí mật ─────────────────────────────────

add_filter( 'rest_authentication_errors', function ( $result ) {
    if ( ! empty( $result ) ) return $result;

    // Bỏ qua khi request từ wp-admin (logged-in user)
    if ( is_user_logged_in() ) return $result;

    $secret = $_SERVER['HTTP_X_WP_SECRET'] ?? '';
    if ( $secret !== WP_API_SECRET ) {
        return new WP_Error( 'rest_forbidden', 'Access denied.', [ 'status' => 403 ] );
    }

    return $result;
} );

// ── 3. CORS — cho phép Next.js server gọi REST API ────────────────────────────

add_action( 'rest_api_init', function () {
    remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

    add_filter( 'rest_pre_serve_request', function ( $value ) {
        $allowed = [ NEXTJS_URL, 'http://localhost:3000', 'https://localhost:3000' ];
        $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';

        if ( in_array( $origin, $allowed, true ) ) {
            header( 'Access-Control-Allow-Origin: ' . $origin );
        }
        header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
        header( 'Access-Control-Allow-Headers: Content-Type, X-WP-Secret, X-WP-Nonce' );
        header( 'Access-Control-Allow-Credentials: true' );

        return $value;
    } );
}, 15 );

// ── 4. Revalidation webhook → Next.js ─────────────────────────────────────────

function _headless_revalidate( array $body ): void {
    wp_remote_post(
        NEXTJS_URL . '/api/revalidate?secret=' . REVALIDATION_SECRET,
        [
            'body'     => wp_json_encode( $body ),
            'headers'  => [ 'Content-Type' => 'application/json' ],
            'timeout'  => 5,
            'blocking' => false, // fire-and-forget
        ]
    );
}

// Khi publish / update bài viết hoặc trang
add_action( 'save_post', function ( $post_id ) {
    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;

    $post = get_post( $post_id );
    if ( ! in_array( $post->post_status, [ 'publish', 'future' ], true ) ) return;

    _headless_revalidate( [
        'post_type' => $post->post_type,
        'post_slug' => $post->post_name,
    ] );
} );

// Khi lưu ACF Options Page (Site Settings)
add_action( 'acf/save_post', function ( $post_id ) {
    if ( $post_id !== 'options' ) return;
    _headless_revalidate( [ 'scope' => 'settings' ] );
} );

// ── 5. Dọn dẹp — tắt các feature không cần trong headless ───────────────────

// Tắt emoji scripts (tiết kiệm ~10KB)
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

// Tắt XML-RPC (không dùng, bảo mật hơn)
add_filter( 'xmlrpc_enabled', '__return_false' );

// Tắt pingback
add_filter( 'wp_headers', function ( $headers ) {
    unset( $headers['X-Pingback'] );
    return $headers;
} );

// Ẩn version WordPress khỏi public
remove_action( 'wp_head', 'wp_generator' );
